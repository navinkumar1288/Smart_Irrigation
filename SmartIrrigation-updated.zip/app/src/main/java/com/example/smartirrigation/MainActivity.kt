package com.example.smartirrigation

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val TAG = "MainActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppShell()
        }
    }

    fun sendSmsSafely(phone: String, text: String): Boolean {
        return try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), 101)
                return false
            }
            val sms = SmsManager.getDefault()
            val parts = sms.divideMessage(text)
            sms.sendMultipartTextMessage(phone, null, parts, null, null)
            true
        } catch (ex: Exception) {
            Log.e(TAG, "SMS failed: ${ex.message}")
            false
        }
    }
}

@Composable
fun AppShell() {
    val tabs = listOf("Dashboard", "Schedules", "Manual", "Settings")
    var current by remember { mutableStateOf(0) }
    val logs = remember { mutableStateListOf<String>() }

    Scaffold(topBar = { TopAppBar(title = { Text("SmartIrrigation") }) },
        bottomBar = {
            BottomNavigation {
                tabs.forEachIndexed { idx, t ->
                    BottomNavigationItem(selected = current==idx, onClick = { current = idx }, icon = { Icon(Icons.Default.Home, contentDescription=null) }, label = { Text(t) })
                }
            }
        }) { inner ->
        Box(modifier = Modifier.padding(inner).fillMaxSize()) {
            when (current) {
                0 -> DashboardScreen(logs)
                1 -> SchedulesScreen(logs)
                2 -> ManualScreen(logs)
                3 -> SettingsScreen(logs)
            }
        }
    }
}

@Composable
fun DashboardScreen(logs: MutableList<String>) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Dashboard", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        Card(modifier = Modifier.fillMaxWidth(), elevation = 4.dp) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Main controller: (configured in Settings)")
                Text("Comm mode: SMS (default)")
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Recent logs")
        LazyColumn {
            itemsIndexed(logs) { i, it -> Text(it, modifier = Modifier.padding(6.dp)) }
        }
    }
}

@Composable
fun SchedulesScreen(logs: MutableList<String>) {
    var list by remember { mutableStateOf(listOf<String>()) }
    var newText by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Schedules", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        Row {
            OutlinedTextField(value = newText, onValueChange = { newText = it }, modifier = Modifier.weight(1f), label = { Text("Schedule (JSON or compact)") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (newText.isNotBlank()) {
                    list = listOf(newText) + list
                    logs.add(0, "Schedule added")
                    newText = ""
                }
            }) { Text("Add") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            itemsIndexed(list) { idx, it ->
                Card(modifier = Modifier.fillMaxWidth().padding(6.dp)) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(it)
                        Row {
                            Button(onClick = { logs.add(0, "Send schedule (stub)") }) { Text("Send") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { /* delete */ }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ManualScreen(logs: MutableList<String>) {
    var node by remember { mutableStateOf("1") }
    var dur by remember { mutableStateOf("60") }
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Manual Control", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value=node, onValueChange={node=it}, label={ Text("Node#") }, modifier=Modifier.width(120.dp))
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(value=dur, onValueChange={dur=it}, label={ Text("Duration s") }, modifier=Modifier.width(120.dp))
            Spacer(Modifier.width(8.dp))
            Button(onClick = { logs.add(0, "OPEN node $node for $dur s (stub)") }) { Text("OPEN") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = { logs.add(0, "CLOSE node $node (stub)") }) { Text("CLOSE") }
        }
    }
}

@Composable
fun SettingsScreen(logs: MutableList<String>) {
    var phone by remember { mutableStateOf("+919944272647") }
    var bleName by remember { mutableStateOf("Wireless_Bridge") }
    var mqttBroker by remember { mutableStateOf("tcp://broker.hivemq.com:1883") }
    var commMode by remember { mutableStateOf("SMS") }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value=phone, onValueChange={phone=it}, label={Text("Controller phone")})
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value=bleName, onValueChange={bleName=it}, label={Text("BLE device name")})
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value=mqttBroker, onValueChange={mqttBroker=it}, label={Text("MQTT broker")})
        Spacer(Modifier.height(8.dp))
        Text("Comm mode")
        Row {
            listOf("SMS","BLE","MQTT").forEach { m ->
                val bg = if (commMode==m) Color(0xFFDDFFDD) else Color.Transparent
                Box(modifier = Modifier.padding(6.dp).background(bg).clickable { commMode = m }.padding(8.dp)) { Text(m) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { logs.add(0, "Settings saved (local only)") }) { Text("Save") }
    }
}
